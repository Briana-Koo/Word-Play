//
//  Word_PlayApp.swift
//  Word Play
//
//  Created by Student on 10/5/21.
//

import SwiftUI

@main
struct Word_PlayApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
